/**
 * The classes in this package represent PetClinic's REST API.
 */

package org.springframework.samples.petclinic.rest;